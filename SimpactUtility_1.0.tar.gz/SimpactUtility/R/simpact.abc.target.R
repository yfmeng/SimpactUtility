simpact.abc.target<-function(results){
  relations <- read.csv(results["logrelations"])
  persons <- read.csv(results['logpersons'])
  # write your own output vector
  # eg
  outputvector<-nrow(relations)
}