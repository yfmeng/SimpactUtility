prior.configure<-function(pcfg){
  ## initiation
  cfg<-list.configure()
  prior<-list()
  k<-1
  for (i in 1:length(cfg)){
    if(is.numeric(cfg[[i]])){
      prior[[k]]<-c('unif',cfg[[i]],cfg[[i]])
      names(prior)[k]<-names(cfg[i])
      k<-k+1
    }
  }
  ## read priors if no input argument
  if(missing(pcfg)){
    # handle keyboard input 
  }
  ## change the priors
  for (i in 1:length(pcfg)){
    prior[[names(pcfg)[i]]]<-pcfg[[i]]
  }
  prior
}