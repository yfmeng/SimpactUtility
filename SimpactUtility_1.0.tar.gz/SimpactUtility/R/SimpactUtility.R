SimpactUtility<-function(){
  package.skeleton(name="SimpactUtility",code_files='SimpactUtility.R')
}